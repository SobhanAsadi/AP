import java.util.ArrayList;

/*
alave bar chiz haye adi ke hame daran, ye inbox dare ke reply supporter ro daryaft mikone
har user hengame gereftan mashin ye destination baraye khodesh etekhaz mikone
 */

public class User {
    private String fistName;
    private String lastName;
    private int kodMeli;
    private String userName;
    private String password;
    private  boolean isDriver;
    private boolean isSupporter;
     boolean isWaitingForCar;
     boolean isOnTheCar;
    private CityEnum city;
     Driver driver;
    private ArrayList<String> inbox = new ArrayList<>();
    private CityEnum destination;

    public User( String fistName, String lastName , String userName , String password ,
                 int kodMeli, boolean isDriver , boolean isSupporter ,
                 boolean isOnTheCar , boolean isWaitingForCar , CityEnum city){
        this.city = city;
       this.isDriver = isDriver;
      this.fistName = fistName;
        this.lastName = lastName;
       this.kodMeli = kodMeli;
        this.userName = userName;
       this.password = password;
        this.isSupporter = isSupporter;
        this.isOnTheCar = isOnTheCar;
        this. isWaitingForCar = isWaitingForCar;
    }

    public User(){};

    public CityEnum getCity() {
        return this.city;
    }

    public int getKodMeli() {
        return this.kodMeli;
    }

    public boolean getIsSupporter() {
        return this.isSupporter;
    }


    public String getFistName() {
        return this.fistName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getPassword() {
        return this.password;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setCity(CityEnum city) {
        this.city = city;
    }

    public void setDriver(boolean driver) {
        this.isDriver = driver;
    }

    public boolean getIsDriver() {
        return this.isDriver;
    }

    public void setOnTheCar(boolean onTheCar) {
        this.isOnTheCar = onTheCar;
    }

    public boolean isOnTheCar() {
        return isOnTheCar;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setWaitingForCar(boolean waitingForCar) {
        this.isWaitingForCar = waitingForCar;
    }

    public void setSupporter(boolean supporter) {
        this.isSupporter = supporter;
    }

    public boolean isWaitingForCar() {
        return this.isWaitingForCar;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setFistName(String fistName) {
        this.fistName = fistName;
    }

    public void setKodMeli(int kodMeli) {
        this.kodMeli = kodMeli;
    }

    public void setMyDriver(Driver driver) {
        this.driver = driver;
    }

    public Driver getMyDriver() {
        return this.driver;
    }

    public void setDestination(CityEnum destination) {
        this.destination = destination;
    }

    public CityEnum getDestination() {
        return this.destination;
    }

    public ArrayList<String> getInbox() {
        return this.inbox;
    }

    public void setInbox(ArrayList<String> inbox) {
        this.inbox = inbox;
    }

    public void cancelTheRide(){ // ba cancel kardan safar, moshtari ranande null mishe
                                 // ranande user null mishe va dige mashin nemikhad

        this.getMyDriver().setMyCostumer(null);
        this.setMyDriver(null);
        this.setWaitingForCar(false);

    }
}

