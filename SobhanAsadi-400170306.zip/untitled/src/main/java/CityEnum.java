
/*
6 city tarif shode ke harkodom number makhsoos be khodeshon ro daran.
ye String name ham bara mavaghe mored niaz bara chap kardan daran.
 */


enum CityEnum {
    Tehran("Tehran" , 1) ,
    Isfahan("Isfahan", 2),
    Ahvaz ("Ahvaz", 3),
    Tabriz("Tabriz" , 4),
    Mashhad("Mashhad",5),
    Rasht("Rasht",6);

    private final String name;
    private final int cityNumber;
    CityEnum (String name , int cityNumber ){
        this.name = name;
        this. cityNumber = cityNumber;
    }

    public int getCityNumber() {
        return cityNumber;
    }

    public String getCityName() {
        return name;
    }
}
