import java.util.ArrayList;
import java.util.Scanner;

/*
in bakhsh marboot be sign up va log in ast.
username ya kode meli ha monhaser be fard hastan
dar vared kardan adad deghat konid
city ha be soorat enum use shodan va karbar shomare shahr khodesh ro entekhab mikone
 */
public class Menu {

    public Menu(int selection, ArrayList<User> userList, ArrayList<String> messageBox, ArrayList<Driver> driversAtCity){

        int cityNumber;
        String firstName;
        String lastName;
        int kodMeli ;
        String username ;
        String password;

        CityEnum city = null;
        int chiz = 0;
        String tmp = null;
        Scanner scanner = new Scanner(System.in);

        if(selection == 0 ) {
            System.out.println("Welcome to Snap!");
            System.out.println("Enter any key to continue...");
            tmp = scanner.nextLine();
        }

        if(tmp != null) {
            System.out.println("Please choose one of the following options...");
            System.out.println("1. Sign up");
            System.out.println("2. Log in");
            System.out.println("3. Quit");
            selection = Integer.parseInt(scanner.nextLine());
        }

            if(selection == 1) {

                System.out.println("Enter your first name: ");
                firstName = scanner.nextLine();

                System.out.println();
                System.out.println("Enter your last name: ");
                lastName = scanner.nextLine();

                System.out.println();
                System.out.println("Enter your username: ");
                username = scanner.nextLine();
                while(usernameCheck(userList,username)) {
                    System.out.println("this username is taken!");
                    System.out.println("choose another one: ");
                    username = scanner.nextLine();
                }

                System.out.println();
                System.out.println("Enter your password: ");
                password = scanner.nextLine();
                System.out.println();

                System.out.println("Enter your kode meli: ");
                kodMeli = Integer.parseInt(scanner.nextLine());
                while(kodmeliCheck(userList,kodMeli)) {
                    System.out.println("this kodMeli is taken!");
                    System.out.println("choose another one: ");
                    kodMeli = Integer.parseInt(scanner.nextLine());
                }
                System.out.println();

                System.out.println("Choose your city by number: ");
                System.out.println("1. Tehran");
                System.out.println("2. Isfahan");
                System.out.println("3. Ahvaz");
                System.out.println("4. Tabriz");
                System.out.println("5. Mashhad");
                System.out.println("6. Rasht");
                cityNumber = Integer.parseInt(scanner.nextLine());
                if(cityNumber == 1) city = CityEnum.Tehran;
                else if (cityNumber == 2)  city = CityEnum.Isfahan;
                else if (cityNumber == 3)  city = CityEnum.Ahvaz;
                else if (cityNumber == 4)  city = CityEnum.Tabriz;
                else if (cityNumber == 5)  city = CityEnum.Mashhad;
                else if (cityNumber == 6)  city = CityEnum.Rasht;


                System.out.println();


                System.out.println("Press 1 if you want to become driver");
                System.out.println("Press 2 if you want to become supporter");
                System.out.println("Otherwise, press any other number ");
                chiz = Integer.parseInt(scanner.nextLine());
                if(chiz == 1){
                   Driver driver =  new Driver(firstName,lastName,username,password,kodMeli,true,false,false,false,city);
                   driversAtCity.add(driver);
                   userList.add(driver);
                }
                else if(chiz == 2){
                   Supporter supporter= new Supporter(firstName,lastName,username,password,kodMeli,false,true,city);
                    userList.add(supporter);
                }
                else{
                   User user = new User(firstName,lastName,username,password,kodMeli,false,false,false,false,city);
                   userList.add(user);
                }


                System.out.println("Welcome. please login");

                new Menu(2,userList,messageBox,driversAtCity);

            }
           else if(selection == 2){

                System.out.println("Enter 1 if you want to go to starter stage: ");
                System.out.println("Otherwise enter any other number: ");
                int n =Integer.parseInt(scanner.nextLine());
                if(n == 1) new Menu (0,userList,messageBox,driversAtCity);

                System.out.println("Enter your username: ");
                username = scanner.nextLine();

                System.out.println("Enter your password: ");
                password = scanner.nextLine();


                if(!usernameCheck(userList, username)){
                    System.out.println("your username doesn't exist!");
                    new Menu(2,userList,messageBox,driversAtCity);
                }
                User newUser = userFinderByUsername(userList,username);


                 if(!(newUser.getPassword().equals(password))){
                    System.out.println("your password is wrong!");
                    new Menu(2,userList,messageBox,driversAtCity);
                }
                else{

                    System.out.println("You've logged in successfully!");

                     if(!(newUser.getIsDriver())&& !(newUser.getIsSupporter())) {
                         new Stage(newUser, 1, userList, messageBox, driversAtCity);
                     }
                     else if((newUser.getIsDriver())&& !(newUser.getIsSupporter())){
                        new Stage(newUser,2,userList,messageBox,driversAtCity);
                     }

                     else if(!(newUser.getIsDriver())&& (newUser.getIsSupporter())){
                        new Stage(newUser,3,userList,messageBox,driversAtCity);
                     }
                }

           }

           else if (selection == 3) {
                System.out.println("Thank you for using Snap!");
                System.out.println("Hope to see you soon!");
                System.exit(0);
           }
           else {
                System.out.println("Wrong number !");
                new Menu(0,userList,messageBox,driversAtCity);
           }
        }
        
        public boolean usernameCheck(ArrayList<User> userList,String username){
            for (User user : userList) {
                if(user.getUserName().equals(username)) return true;
            }
            return false;
        }

    public boolean passwordCheck(ArrayList<User> userList,String password){
        for (User user : userList) {
            if(user.getUserName().equals(password)) return true;
        }
        return false;
    }

    public boolean kodmeliCheck(ArrayList<User> userList,int kodmeli){
        for (User user : userList) {
            if(user.getKodMeli()== kodmeli) return true;
        }
        return false;
    }
    public User userFinderByUsername(ArrayList<User> userList, String username){
        for (User user : userList) {
            if(user.getUserName().equals(username)) return user;
        }

        return null;
    }
    public Driver driverFinderByUsername(ArrayList<Driver> driverList, String username){
        for (Driver driver : driverList) {
            if(driver.getUserName().equals(username)) return driver;
        }

        return null;
    }

    public Supporter supporterFinderByUsername(ArrayList<Supporter> supporterList, String username){
        for (Supporter supporter : supporterList) {
            if(supporter.getUserName().equals(username)) return supporter;
        }

        return null;
    }


        }


