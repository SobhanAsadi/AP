import java.io.Console;
import java.util.ArrayList;
import java.util.Scanner;

/*
class marboot be samte karbare va option haye mokhtalef ro neshon mide
user ya mitone mashin begire ya payam be supporter bede ya inboxesho check kone
inbox jaiie ke reply supporter onja miad
 */
public class UserStage {

    public UserStage(boolean isWaitingForCar, int selection, User user, ArrayList<User> userList,
                     ArrayList<String> messageBox, ArrayList<Driver> driversAtCity) {

        Scanner scanner = new Scanner(System.in);
        Driver chosenDriver = null;

        if (isWaitingForCar) {

            System.out.println(user.getMyDriver().getFistName() + " " + user.getMyDriver().getLastName() + " with kode meli " +
                    user.getMyDriver().getKodMeli() + " has been chosen for you!");
            System.out.println("please wait...");
            boolean flag = true;

            System.out.println("enter 1 to cancel:");
            System.out.println("enter 2 to LogOut:");


            while (flag) {
                int chiz = Integer.parseInt(scanner.nextLine());

                if (chiz == 1) {
                        user.cancelTheRide();
                        new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
                        flag = false;
                        System.out.println("you didn't enter a number!");
                } else if (chiz == 2) {
                    new Menu(0, userList, messageBox, driversAtCity);
                    flag = false;
                } else {
                    System.out.println("that a wrong number!");
                    System.out.println();
                }
            }
        }

        else if(user.isOnTheCar()){
            System.out.println(user.getMyDriver().getFistName() + " " + user.getMyDriver().getLastName() + "with kode meli " +
                    user.getMyDriver().getKodMeli() + " is giving you a ride to "+user.getDestination().getCityName());

            boolean flag = true;
            System.out.println("enter 1 to cancel:");
            System.out.println("enter 2 to LogOut:");


            while (flag) {
                int chiz = Integer.parseInt(scanner.nextLine());

                if (chiz == 1) {

                    user.setMyDriver(null);
                    user.setWaitingForCar(false);
                    user.getMyDriver().setMyCostumer(null);
                    user.setOnTheCar(false);
                    user.setDestination(null);

                    new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
                    flag = false;
                } else if (chiz == 2) {
                    new Menu(0, userList, messageBox, driversAtCity);
                    flag = false;
                } else {
                    System.out.println("that a wrong number!");
                    System.out.println();
                }
            }
        }

        else {
            if (selection == 0) {
                System.out.println("** " + user.getFistName() + " " + user.getLastName() + "'s panel **");
                System.out.println("Please choose one of the following options...");
                System.out.println("1. Find cars in " + user.getCity().getCityName());
                System.out.println("2. Ask question from a supporter");
                System.out.println("3. Inbox");
                System.out.println("4. Log Out");

                selection = Integer.parseInt(scanner.nextLine());
                new UserStage(user.isWaitingForCar, selection, user, userList, messageBox, driversAtCity);
            } else if (selection == 1) {
                int counter = 1;
                int chiz = 0;
                for (Driver driver : driversAtCity) {
                    if ((driver.getCity() == user.getCity()) && (driver.doesWantMoshtari())) {
                        chosenDriver = driver;
                    }
                }
                if (chosenDriver == null) {
                    System.out.println("there is no driver in " + user.getCity().getCityName());
                    System.out.println();
                }
                else {
                    chosenDriver.setMyCostumer(user);
                    user.setMyDriver(chosenDriver);
                    user.setWaitingForCar(true);
                    System.out.println("Where do you want to go?");
                    System.out.println("1. Tehran");
                    System.out.println("2. Isfahan");
                    System.out.println("3. Ahvaz");
                    System.out.println("4. Tabriz");
                    System.out.println("5. Mashhad");
                    System.out.println("6. Rasht");

                    int cityNumber = Integer.parseInt(scanner.nextLine());
                    CityRecogniser(user,cityNumber);


                    if(user.getDestination() == user.getCity()){
                        System.out.println("You are in "+user.getCity().getCityName()+"!");
                        user.setDestination(null);
                        user.setWaitingForCar(false);

                    }
                }
                new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
            } else if (selection == 2) {
                System.out.println("type your message!");
                messageBox.add(user.getUserName()+"::"+scanner.nextLine());
                System.out.println("our supporters will answer you as soon as possible!");
                System.out.println();
                new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
            } else if (selection == 3) {

                    int counter = 1;
                    for (String str : user.getInbox()) {
                        System.out.println(counter + ". " + str);
                        counter++;
                    }
                    counter --;
                if(counter == 0){
                    System.out.println("Your Inbox is empty!");
                    System.out.println();
                    new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
                }
                else {
                    int chiz;
                    System.out.println();
                    System.out.println("Enter the number of message you want to delete");
                    System.out.println("for going to starter stage, enter 0");
                    chiz = Integer.parseInt(scanner.nextLine());
                    if (chiz == 0) {
                        new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
                    } else if (chiz > counter) {
                        System.out.println("that's a wrong number!");
                        new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
                    } else {
                        user.getInbox().remove(chiz - 1);
                        System.out.println("it has been removed!");
                        new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
                    }
                }





            } else if (selection == 4) {
                new Menu(0, userList, messageBox, driversAtCity);
            }
            else {
                System.out.println("that's a wrong number!");
                System.out.println();
                new UserStage(user.isWaitingForCar, 0, user, userList, messageBox, driversAtCity);
            }
        }

    }

    public void CityRecogniser (User user, int cityNumber){
        if(cityNumber == 1) user.setDestination(CityEnum.Tehran);
        else if (cityNumber == 2)  user.setDestination(CityEnum.Isfahan);
        else if (cityNumber == 3)  user.setDestination(CityEnum.Ahvaz);
        else if (cityNumber == 4)  user.setDestination(CityEnum.Tabriz);
        else if (cityNumber == 5)  user.setDestination(CityEnum.Mashhad);
        else if (cityNumber == 6)  user.setDestination(CityEnum.Rasht);
    }
}


