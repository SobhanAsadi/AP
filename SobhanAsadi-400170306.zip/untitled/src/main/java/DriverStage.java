import java.util.ArrayList;
import java.util.Scanner;


/*
class marboot be samte karbare va option haye mokhtalef ro neshon mide
driver ya mitone moshtari bekhad ya nakhad.
bad az inke ye moshtari barash peyda shod ya mitone safar ro be anjam beresone ya cancel kone
agar safar be anjam resid, shahr khodesh va moshtari be destination change mishe
 */
public class DriverStage {
    public DriverStage(int selection , Driver driver, ArrayList<User> userList, ArrayList<String> messageBox, ArrayList<Driver> driversAtCity) {
        Scanner scanner = new Scanner(System.in);
        User chosenUser = null;
        boolean flag = true;
        int number;

        if(driver.getMyCostumer() != null){

            System.out.println("I'm driving right now!");
            System.out.println("choose on of the following options:");
            System.out.println("1. we've arrived to the destination!");
            System.out.println("2. cancel the ride!");
            System.out.println("3. logout");

            number = Integer.parseInt(scanner.nextLine());


                if (number == 1) {
                    driver.drive();

                    System.out.println();
                    System.out.println("Welcome to "+driver.getCity().getCityName()+"!");
                    System.out.println();
                    new DriverStage(0,driver,userList,messageBox,driversAtCity);

                } else if (number == 2) {

                    driver.cancelTheRide();
                    System.out.println();
                    new DriverStage(0,driver,userList,messageBox,driversAtCity);
                } else if (number == 3) {
                    new Menu(0, userList, messageBox, driversAtCity);
                }
                else {
                    System.out.println("that a wrong number!");
                    System.out.println();
                    new DriverStage(0,driver,userList,messageBox,driversAtCity);
                }

        }

        else{

            if(selection == 0){


                System.out.println("** " + driver.getFistName() + " " + driver.getLastName() + "'s panel **");
                System.out.println("Please choose one of the following options...");
                System.out.println("1. I'm ready to get costumer in " + driver.getCity().getCityName());
                System.out.println("2. I'm not ready to have costumers");
                System.out.println("3. Log Out");

                selection = Integer.parseInt(scanner.nextLine());

                new DriverStage(selection,driver,userList,messageBox,driversAtCity);


            }
            else if(selection == 1){

                driver.setWantsMoshtari(true);
                System.out.println("Done!");
                System.out.println();
                new DriverStage(0,driver,userList,messageBox,driversAtCity);

            }
            else if(selection == 2){

                driver.setWantsMoshtari(false);
                System.out.println("Done!");
                System.out.println();
                new DriverStage(0,driver,userList,messageBox,driversAtCity);

            }
            else if(selection == 3){
                new Menu(0, userList, messageBox, driversAtCity);
            }
            else{

                System.out.println("that a wrong number!");
                System.out.println();
                new DriverStage(0,driver,userList,messageBox,driversAtCity);

            }

        }


    }
}
