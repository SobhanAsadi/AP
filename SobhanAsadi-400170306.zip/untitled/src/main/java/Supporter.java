

/*
payame User ra mikhanad va beine payam haii ke darad, yeki ra entekhab mikonad va an ra reply mikonad.
 */
public class Supporter extends User {

        private String fistName;
    private String lastName;
    private int kodMeli;
    private String userName;
    private String password;
    private boolean isDriver;
    private boolean isSupporter;
    private CityEnum city;

        public Supporter(String fistName, String lastName, String userName, String password,
                      int kodMeli, boolean isDriver, boolean isSupporter, CityEnum city) {

            this.city = city;
            this.isDriver = isDriver;
            this.fistName = fistName;
            this.lastName = lastName;
            this.kodMeli = kodMeli;
            this.userName = userName;
            this.password = password;
            this.isSupporter = isSupporter;
        }



        @Override
        public String getPassword() {
            return this.password;
        }

        @Override
        public String getLastName() {
            return this.lastName;
        }

        @Override
        public String getFistName() {
            return this.fistName;
        }

        @Override
        public String getUserName() {
            return this.userName;
        }

        @Override
        public int getKodMeli() {
            return this.kodMeli;
        }

        @Override
        public CityEnum getCity() {
            return this.city;
        }

        @Override
        public void setPassword(String password) {
            this.password = password;
        }

        @Override
        public void setWaitingForCar(boolean waitingForCar) {
            this.isWaitingForCar = waitingForCar;
        }

        @Override
        public void setOnTheCar(boolean onTheCar) {
            this.isOnTheCar = onTheCar;
        }

        @Override
        public void setSupporter(boolean supporter) {
            this.isSupporter = supporter;
        }

        @Override
        public void setDriver(boolean driver) {
            this.isDriver = driver;
        }

        public void setFistName(String fistName) {
            this.fistName = fistName;
        }


        public void setKodMeli(int kodMeli) {
            this.kodMeli = kodMeli;
        }

        @Override
        public void setCity(CityEnum city) {
            this.city = city;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

    @Override
    public boolean getIsSupporter() {
        return this.isSupporter;
    }

    @Override
    public boolean getIsDriver() {
        return this.isDriver;
    }

}


