import java.util.ArrayList;



public class Main {
    public static void main(String[] args) {

        ArrayList<Driver> driversAtCity = new ArrayList<>();
        ArrayList<User> userList = new ArrayList<>();
        ArrayList<String> messageBox = new ArrayList<>();
        new Menu(0,userList,messageBox,driversAtCity);

    }
}


