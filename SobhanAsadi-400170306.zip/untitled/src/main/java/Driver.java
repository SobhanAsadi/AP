public class Driver extends User {
    private boolean isBusy;
    private int score;
    private boolean wantsMoshtari;
    private boolean isOnBlackList;
    private  String fistName;
    private String lastName;
    private int kodMeli;
    private String userName;
    private String password;
    private int money;
    private boolean isDriver;
    private boolean isSupporter;
    private CityEnum city;

    private User myCostumer;

    public Driver(String fistName, String lastName, String userName, String password,
                  int kodMeli, boolean isDriver, boolean isSupporter,
                  boolean isBusy,boolean wantsMoshtari, CityEnum city) {
        this.city = city;
        this.isDriver = isDriver;
        this.fistName = fistName;
        this.lastName = lastName;
        this.kodMeli = kodMeli;
        this.userName = userName;
        this.password = password;
        this.isSupporter = isSupporter;
        this.isBusy = isBusy;
        this.wantsMoshtari = wantsMoshtari;
    }

    public int getScore() {
        return this.score;
    }

    public void setOnBlackList(boolean onBlackList) {
        this.isOnBlackList = onBlackList;
    }

    public void setWantsMoshtari(boolean wantsMoshtari) {
        this.wantsMoshtari = wantsMoshtari;
    }

    public void setBusy(boolean driving) {
        this.isBusy = driving;
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getLastName() {
        return this.lastName;
    }

    @Override
    public String getFistName() {
        return this.fistName;
    }

    @Override
    public String getUserName() {
        return this.userName;
    }

    @Override
    public int getKodMeli() {
        return this.kodMeli;
    }

    @Override
    public CityEnum getCity() {
        return this.city;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public void setWaitingForCar(boolean waitingForCar) {
        this.isWaitingForCar = waitingForCar;
    }

    @Override
    public void setOnTheCar(boolean onTheCar) {
        this.isOnTheCar = onTheCar;
    }

    @Override
    public void setSupporter(boolean supporter) {
        this.isSupporter = supporter;
    }

    public void addMoney(int money) {
        this.money += money;
    }

    @Override
    public void setDriver(boolean driver) {
        this.isDriver = driver;
    }

    public void setFistName(String fistName) {
        this.fistName = fistName;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public void setKodMeli(int kodMeli) {
        this.kodMeli = kodMeli;
    }

    @Override
    public void setCity(CityEnum city) {
        this.city = city;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void addScore(int score) {
        this.score += score;
    }


    public boolean getIsBusy() {
        return this.isBusy;
    }

    public boolean isOnBlackList() {
        return this.isOnBlackList;
    }

    public boolean doesWantMoshtari() {
        return this.wantsMoshtari;
    }

    public boolean isOnTheCar() {
        return this.isOnTheCar;
    }

    public User getMyCostumer() {
        return this.myCostumer;
    }

    public void setMyCostumer(User myCostumer) {
        this.myCostumer = myCostumer;
    }

    @Override
    public boolean getIsDriver() {
        return this.isDriver;
    }

    @Override
    public boolean getIsSupporter() {
        return this.isSupporter;
    }

    public void drive(){ // city khodesh va user ro taghir mide. bad az resondan moshtari dar halat pishfarz, dige moshtari nemikhad,
                         // maghsad va driver va mashin khastan moshtari null mishe
                         // moshtari link shode be ranande null mishe

        this.setCity(this.getMyCostumer().getDestination());
        this.getMyCostumer().setCity(this.getMyCostumer().getDestination());
        this.setWantsMoshtari(false);
        this.getMyCostumer().setDestination(null);
        this.getMyCostumer().setMyDriver(null);
        this.getMyCostumer().setWaitingForCar(false);
        this.setMyCostumer(null);
    }

    public void cancelTheRide(){ // maghsad va driver va mashin khastan moshtari null mishe
                                 // moshtari link shode be ranande null mishe va dg moshtari nemikhad
        this.setWantsMoshtari(false);
        this.setMyCostumer(null);
        this.getMyCostumer().setDestination(null);
        this.getMyCostumer().setMyDriver(null);
        this.getMyCostumer().setWaitingForCar(false);
    }

}
