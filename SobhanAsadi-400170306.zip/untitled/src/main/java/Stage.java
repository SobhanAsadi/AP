import java.util.ArrayList;

/*
in class dar vaghe rabet beine UserStage, DriverStage va SupporterStage hast.
ba tavajoh be User ya Driver ya Supproter bodan karbar log in shode, be bakhsh marboot be khodesh mire.
 */
public class Stage {


    public Stage(User user, int n, ArrayList<User> userList, ArrayList<String> messageBox, ArrayList<Driver> driversAtCity){
        if(n == 1){
            new UserStage(user.isWaitingForCar(),0,user,userList,messageBox,driversAtCity);
        }
        else if(n == 2){
            new DriverStage(0,(Driver) user,userList,messageBox,driversAtCity);
        }
        else if(n == 3){
            new SupporterStage(0,(Supporter) user,userList,messageBox,driversAtCity);
        }
    }
}
