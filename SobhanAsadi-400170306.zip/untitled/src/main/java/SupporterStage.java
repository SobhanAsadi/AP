import java.util.ArrayList;
import java.util.Scanner;

/*
handel kardane taamolate supprter inja soorat migire.
payame User ra mikhanad va beine payam haii ke darad, yeki ra entekhab mikonad va an ra reply mikonad.
reply be inbox user morede nazar miravad.
user mibinad ke che supporteri be oo pasokh dade (kod meli supporter baraye oo namayesh dade mishavad.
 */
public class SupporterStage {
    public SupporterStage(int selection , Supporter supporter, ArrayList<User> userList, ArrayList<String> messageBox, ArrayList<Driver> driversAtCity) {
        Scanner scanner = new Scanner(System.in);
        if(selection == 0) {
            System.out.println("** " + supporter.getFistName() + " " + supporter.getLastName() + "'s panel **");
            System.out.println("Please choose one of the following options...");
            System.out.println("1. check inbox");
            System.out.println("2. Log Out");
            selection = Integer.parseInt(scanner.nextLine());
            new SupporterStage(selection,supporter,userList,messageBox,driversAtCity);
        }
        else if(selection == 1) {
            int counter = 1;
            for (String str : messageBox) {
                System.out.println(counter + ". " + str);
                counter++;
            }
            counter--;
            if (counter == 0) {
                System.out.println("Your Inbox is empty!");
                System.out.println();
                new SupporterStage(0, supporter, userList, messageBox, driversAtCity);
            } else {
                System.out.println("select which number you want to reply to:");
                int n = Integer.parseInt(scanner.nextLine());

                if (n > counter) {
                    System.out.println("Wrong number!");
                } else {
                    String str;
                    System.out.println("PLease type your reply:");
                    str = scanner.nextLine();
                    String[] chiz = messageBox.get(n - 1).split("::", 2);
                    User user = userFinderByUsername(userList, chiz[0]);
                    user.getInbox().add("Supporter(" + supporter.getKodMeli() + "): " + str);
                    System.out.println("Your reply has been successfully sent!");
                    messageBox.remove(n - 1);
                }
                new SupporterStage(0, supporter, userList, messageBox, driversAtCity);
            }
        }
        else if(selection == 2){
            new Menu(0, userList, messageBox, driversAtCity);
        }
        else {
            System.out.println("that's a wrong number!");
            System.out.println();
            new SupporterStage(0,supporter,userList,messageBox,driversAtCity);
        }
    }
    public User userFinderByUsername(ArrayList<User> userList, String username){
        for (User user : userList) {
            if(user.getUserName().equals(username)) return user;
        }

        return null;
    }
}
